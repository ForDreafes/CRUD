<?php

    //A funcao file_get_contents obtem os dados do arquivo  contatos.json e
    // atribui seu conteudo a variavel $contatos_json
    $contatos_json  = file_get_contents('contatos.json');

    $contatos_array = json_decode($contatos_json, true);

//    echo '<pre>';
//    print_r($contatos_array);
//    echo '</pre>';

    if ( isset($_GET['acao']) ){

        //CADASTRAR
        if ($_GET['acao'] == 'cadastrar') {

            //print_r($_POST);

            $novoContato = [
                "name"   => $_POST['campo_nome'],
                "email"  => $_POST['campo_email'],
                "number" => uniqid(),
            ];
            if (empty($_POST['campo_nome'] == False) and empty($_POST['campo_email' == False])) {
                //atualiza o array de contatos
                $contatos_array[] = $novoContato;

                //tbm atualiza o arquivo.json
                $json = json_encode($contatos_array, JSON_PRETTY_PRINT);        //
                file_put_contents('contatos.json', $json);                      //
            }else{
                print ("<h1> Preencha o nome e o E-mail </h1>");
            }



        }

        //DELETE
        if ($_GET['acao'] == 'excluir'){
            echo 'tentou excluir o ' . $_GET['numero'];

            foreach ($contatos_array as $pos => $contato) {

                if ($contato['number'] == $_GET['numero']){
                    echo " Encontrei o contato";
                    unset( $contatos_array[$pos] );
                    $json = json_encode($contatos_array, JSON_PRETTY_PRINT);    //
                    file_put_contents('contatos.json', $json);                  //
                    break;
                }else {
                    // echo "nao foi esse contato <br>";
                }

            }

        }

        //UPDATE
        if ($_GET['acao'] == 'editar'){
            echo 'tentou editar o ' . $_GET['numero'];

            foreach ($contatos_array as $contato) {
                if ($_GET['numero'] == $contato['number']) {
                    $contatoEncontrado = $contato;
                    break;
                }
            }
        }//fim de if editar

        if ($_GET['acao'] == 'salvar_contato_editado') {

            foreach ($contatos_array as $pos => $contato) {

                if ($_POST['campo_numero'] == $contato['number']) {
                    $contatos_array[$pos]['name'] = $_POST['campo_editar_nome'];
                    $contatos_array[$pos]['email'] = $_POST['campo_editar_email'];

                }

            }
            //tbm atualiza o arquivo.json
            $json = json_encode($contatos_array, JSON_PRETTY_PRINT);        //
            file_put_contents('contatos.json', $json);


        }
    }

?>

            <!-- Formulário de cadastro -->

<body style="margin-left: 30%; margin-top: 5%;">

        <section style="margin-left: 14.5%;">
            <h1 style="margin: 5%; font-size: 150%;">Formulário de cadastro</h1>

            <form method="post" action="?acao=cadastrar">
                <input type="text" name="campo_nome" placeholder="digite um nome">
                <input type="text" name="campo_email" placeholder="digite um e-mail">

                <input type="submit" value="cadastrar">
            </form>

            <!-- Formulário de editar -->

            <form method="post" action="?acao=salvar_contato_editado">
                <input type="hidden" value="<?= @$contatoEncontrado['number']?>" name="campo_numero">
                <input type="text" value="<?= @$contatoEncontrado['name']?>" name="campo_editar_nome" placeholder="digite um nome">
                <input type="text" value="<?= @$contatoEncontrado['email']?>" name="campo_editar_email" placeholder="digite um e-mail">

                <input type="submit" value="atualizar">
            </form>

        </section>

    <table style="border: solid;">

        <tr>
            <td style="border-bottom: solid;">Número</td>
            <td style="border-bottom: solid;">Nome</td>
            <td style="border-bottom: solid;">E-mail</td>
            <td style="border-bottom: solid;">Editar</td>
            <td style="border-bottom: solid;">Excluir</td>
        </tr>


        <?php foreach ($contatos_array as $pessoa): ?>

            <tr>
                <td style="border-right: solid;"><?= $pessoa['number'] ?></td>
                <td style="border-right: solid;"><?= $pessoa['name'] ?></td>
                <td style="border-right: solid;"><?= $pessoa['email'] ?></td>
                <td style="border-right: solid;"><a href="?acao=editar&numero=<?= $pessoa['number'] ?>">editar</a></td>
                <td><a href="?acao=excluir&numero=<?= $pessoa['number'] ?>">excluir</a></td>
            </tr>
            
        <?php endforeach; ?>

    </table>
</body>