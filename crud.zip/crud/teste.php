<?php
    $texto = 'oi';
